from selenium.webdriver.common.by import By
from pages.base_page import BasePage

class LoginPage(BasePage):
    username_input = (By.ID, "user-name")
    password_input = (By.ID, "password")
    login_btn = (By.ID, "login-button")

    def login(self, username, password):
        self.type_text(self.username_input,username)
        self.type_text(self.password_input,password)
        self.click(self.login_btn)