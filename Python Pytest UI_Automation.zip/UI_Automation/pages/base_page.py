from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from utils.logger import get_logger

class BasePage:
    def __init__(self, driver):
        self.driver=driver
        self.logger=get_logger(self.__class__.__name__)
    
    def open_url(self, url):
        self.driver.get(url)

    def find_element(self, locator, timeout=10):
        return WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located(locator)
        )
    
    def click(self, locator):
        self.find_element(locator).click()

    def type_text(self, locator, text):
        element=self.find_element(locator)
        element.clear()
        element.send_keys(text)