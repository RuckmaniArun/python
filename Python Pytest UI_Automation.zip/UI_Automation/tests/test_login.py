import pytest
from pages.login_page import LoginPage
from config.constants import config
import time

def test_login_valid_user(setup):
    driver=setup

    try:
        login_page=LoginPage(driver)

        print(config)
        login_page.open_url(config["base_url"])
        login_page.login(
            config["credentials"]["username"], 
            config["credentials"]["password"]
        )
        time.sleep(10)
        assert "Swag Labs" in driver.title

    except AssertionError as e:
        print("Login failed")
        raise
    
    finally:
        driver.quit()