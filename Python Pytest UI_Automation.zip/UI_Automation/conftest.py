string input="Automation"

StringBuilder sb=new StringBuilder(input);
sb.reverse()

string reversed=sb.toString();

for(int i=input.length();i>=0;i--)
	reversed=reversed+input.charAt(i)


input.equals(reversed)

Map<Character, Integer> map=new HashMap<>();

for (char c: input.toCharArray()){
	map.input(c, map.getorDefault(c,0)+1)

for(Map.Entry(Character, Integer) entry: map.entrySet()){
	if(entry.getValue() >1)
		S.o.p(entry.getKey())

Map<Character, Integer> map=new HashMap<>();

for(char c:input.toCharArray())
	map.get(c,map.getorDefault(c,0)+1)

for(Map.entry<Character, Integer> entry: Map.entryset())
	for(entry.getValue() >1)
		s.o.p(entry.getKey())	


int[] arr={1,3,4,4,45}

Set<Integer> set=new HashSet<>();

for (int i : arr){
if(!set(add(i))){
system.println.i(i))

if(set.contain(i))
{s.o.p(i)
}else
set.add(i))

int[] arr={1,3,4,6,7,6}

Arrays.sort(arr);

int j=0
for(int =1; i < arr.length-1;i++)
	if(arr[i]!=arr[i+1)
		arr[j]=arr[i]
		j++

arr[j]=arr[arr.length-1]

for(int i=0;i<j;i++)
	s.o.p(arr[i]

int a=5
int b=10

a=a+b = 15
b=a-b =5
a=a-b =

System.out.println(a + " "+ b)

map.put(word, map.getorDefault(word,0)+1)

String str="automation";
Map<Character, Integer> map=new HashMap<>();

for(char c:str.toCharArray())
	map.put(c,map.getOrDefault(c,0)+1);

for(Map.Entry<Character, Integer> entry: map.entryset())
	if(entry.value()>1)
		en

    int arr[]={100,11,23,11,44};

int largest=Integer.MIN_VALUE;
int second_largest=Integer.MIN_VALUE;

for(int i=0;i<arr.length;i++){
	if(arr[i] > largest){
		second_largest=largest;
		largest=arr[i];
	}else if(arr[i]>second_largest && arr[i]!=largest)
		second_largest=arr[i];
}
System.out.println("Largest: "+largest);
System.out.println("Second_Largest: "+second_largest);

StringBuilder sb=new StringBuilder(input)

sb.reverse();

String reversed=sb.ToString()

String sentence=

Map<Sting, Integer> map=new HashMap<>();
map.put("A",8)
map.put("B",2)
map.put("C",1)

map.entrySet().stream().
.sorted(Map.Entry.ComparingByValue())
.foreach(System.out.println)


List<WebElements> links=driver.findElements(By.tagName("a"));

for(WebElement link : links)
	System.out.println(link.getText()+"-->"+link.getAttribute("href"))

Link<WebElements> links=driver.findElements(By.tagname("a"))

String LoginText="Dashboard"
for(WebElement link: links)
	if(link.getText().equals(LoginText))
		link.click()
		break;

WebElement dropdown=driver.fine
Select select=new Select(dropdown)

select.selectByVisibileText("cananda")

driver.findElement(By.id("AlertBtn")).click();
Alert alert=driver.switchTo().Alert();

alert.accept();

WebDriver wait=new WebDriverWait();
WebElement element=wait.until(ExpectedConditions.VisibilityOfElementLocated(By.xpath(//input[text()='login'))
element.click()

given()
	.when()
	.get("https://api/getrequest/123").
	.then()
	.StatusCode(200)
	.body("id", equalTo(123));


given()
	.when()
	.get("")
	.then()
	.statuscode(200)
	.body("id",equalTo(123));

class API_Test {

public static void main(string[] args){

RestAssured.baseURI="https://testapi.com"

s.o.p("Get request")

given()
	.when()
	.get(("/users/123"))
	.then()
	.statuscode("200")
	.body("id",equalTo(123))
	.body("name",equalTo("alex"))

system.out.println("Post")

String requestBody="{\n"+
		    " \"title\" : \"API_check\","\n"+
                    " \userid\":\"alex\","\n"+
		}";

given().
	.header("conent-type", "application/josn")
	.and()
	.body(requestBody)
when()
	.post("/post")
.then()
	.statuscode(201)
	.body("id",equalTo(123))
	.body("title",equalTo("API_check"))

String input="Automation"
String reversed=""

StringBuilder sb=new StringBuilder(input)

reversed=sb.reverse().toString();

System.out.println(reversed)

for(int i=input.length()-1;i>=0;i--)
	reverse=reverse+input.charAt(i)

Map<character,Integer> map=new HashMap<>();

for(char c: str.toCharArray())
map.put(c,map.getorDefault(c,0)+1)

Map.Entry<

List<String> types=response.jsonPath().getList("transaction.type")

Map<String, Integer> map=new HashMap<>();

for(String type: types){
map.put(type,map.getorDefault(type,0)+1)

assertEquals(3, count(map.get("CREDIT"))
assertEquals(2,count(map.get("DEBIT"))

List<String> emails=response.jsonPath().getList("users.email")
Map<String, Integer> map=new HashMap<>()

for(String email: emails)
map.put(email, map.getOrDefault(email,0)+1)

map.foreach((key, value) --> {
if(value>1)
print("Duplicate Key")

})

Set<Integer> set=new Hashset<>();

for(int num: arr){
set.add(num)

String[] uniqueArr=Arrays.stream(arr).distinct().toArray(String[]::new);

Arrays.toString(uniqueArr)
	.
