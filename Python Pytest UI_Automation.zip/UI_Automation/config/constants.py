import yaml

def load_config(path="config/config.yaml"):
    with open(path,'r') as fp:
        config=yaml.safe_load(fp)
    return config

config=load_config()